export default function Home() {
  return (
    <main className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="text-center">
          <h1 className="text-4xl font-bold text-lime-400">Gamer Gear Zone</h1>
          <p className="text-lg text-gray-300 mt-2">Affordable Gaming Accessories & PC Gear Picks</p>
        </header>

        <section className="bg-gray-900 p-6 rounded-2xl shadow-xl">
          <h2 className="text-2xl font-semibold mb-4 text-lime-300">🔥 Featured Picks</h2>
          <ul className="space-y-4">
            <li>
              <a 
                href="https://www.amazon.com/dp/B07W6JHVZW?tag=youraffiliateid" 
                target="_blank" 
                className="block bg-gray-800 p-4 rounded-xl hover:bg-gray-700 transition"
              >
                🎧 HyperX Cloud II – Best Budget Gaming Headset
              </a>
            </li>
            <li>
              <a 
                href="https://www.amazon.com/dp/B07D6ZHN4S?tag=youraffiliateid" 
                target="_blank" 
                className="block bg-gray-800 p-4 rounded-xl hover:bg-gray-700 transition"
              >
                🖱️ Logitech G203 – Best Value Gaming Mouse
              </a>
            </li>
            <li>
              <a 
                href="https://www.amazon.com/dp/B07R7RHF5K?tag=youraffiliateid" 
                target="_blank" 
                className="block bg-gray-800 p-4 rounded-xl hover:bg-gray-700 transition"
              >
                ⌨️ Redragon K552 – Best Mechanical Keyboard Under $50
              </a>
            </li>
          </ul>
        </section>

        <section className="bg-gray-900 p-6 rounded-2xl shadow-xl">
          <h2 className="text-2xl font-semibold mb-4 text-lime-300">💡 Tips & Reviews</h2>
          <p className="text-gray-400">
            Coming soon: deep dives on how to build a budget gaming setup, gear comparisons, and more!
          </p>
        </section>

        <footer className="text-center text-gray-500 mt-10">
          <p>&copy; 2025 Gamer Gear Zone. Powered by passion, built for gamers.</p>
        </footer>
      </div>
    </main>
  );
}
